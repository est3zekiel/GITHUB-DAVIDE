class Cliente:
    def __init__(self, nome="", cognome="", telefono="", id=0):
        self.nome=nome
        self.cognome=cognome
        self.telefono=telefono
        self.id=id

    @property
    def nome(self):
        return self._nome

    @nome.setter
    def nome(self, nome):
        self._nome=nome

    @property
    def cognome(self):
        return self._cognome

    @cognome.setter
    def cognome(self, cognome):
        self._cognome=cognome

    @property
    def telefono(self):
        return self._telefono

    @telefono.setter
    def telefono(self, telefono):
        self._telefono=telefono

    @property
    def id(self):
        return self._id

    @id.setter
    def id(self, id):
        self._id=id

    def info(self):
        return self.nome+" " +self.cognome+" " +self.telefono

