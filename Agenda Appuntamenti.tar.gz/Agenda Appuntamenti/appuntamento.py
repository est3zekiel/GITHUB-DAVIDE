import datetime
class Appuntamento:
    def __init__(self, id=0, data=datetime.datetime.now(), ora=0, idCliente=0):
        self.id=id
        self.data=data
        self.ora=ora
        self.idCliente=idCliente

    @property
    def id(self):
        return self._id

    @id.setter
    def id(self, id):
        self._id=id

    @property
    def data(self):
        return self._data

    @data.setter
    def data(self, data):
        self._data=data

    @property
    def idCliente(self):
        return self._idCliente

    @idCliente.setter
    def idCliente(self, idCliente):
        self._idCliente=idCliente

    def info(self):
        return str(self.id)+" "+str(self.data.strftime("%a %d-%m-%Y"))+" "+str(self.ora)
