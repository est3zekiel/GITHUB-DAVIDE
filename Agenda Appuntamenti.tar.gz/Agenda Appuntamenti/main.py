# Il main chiama le funzioni
from provaDatetime import somma
from view import IO
from view import Menu
import repository

def f1(clienteRepo,appuntamentoRepo): # Crea Nuovo cliente (MOD poter annullare con comando durante inserimento ex: !annulla)
    nuovoCliente=IO.acqCliente()
    idCliente=clienteRepo.add(nuovoCliente)
    IO.visMsg("Cliente creato con ID: "+ str(idCliente))

def f2(clienteRepo,appuntamentoRepo): # Info Cliente (MOD prospetta lista prima, controllo input poi)
    idCliente=IO.idCliente()
    cliente=clienteRepo.get(idCliente)
    listaAppuntamenti=appuntamentoRepo.getAppByCliente(cliente)
    IO.visMsg("Gli appuntamenti del cliente sono: ")
    IO.visCliente(cliente)
    for app in listaAppuntamenti:
        IO.visMsg(app.info() + " " + cliente.info())
    
def f3(clienteRepo,appuntamentoRepo): # Modifica Cliente
    idCliente=IO.idCliente()
    cliente=clienteRepo.get(idCliente)
    nuovoCliente=IO.acqCliente()
    nuovoCliente.id=cliente.id
    clienteRepo.save(nuovoCliente)

def f4(clienteRepo,appuntamentoRepo): # Elimina Cliente
    idCliente=IO.idCliente()
    cliente=clienteRepo.get(idCliente)
    clienteRepo.delete(cliente.id)

def f5(clienteRepo,appuntamentoRepo): # Prenota Appuntamento
    nuovoAppuntamento=IO.acqAppuntamento()
    idAppuntamento=appuntamentoRepo.add(nuovoAppuntamento)
    IO.visMsg("Appuntamento creato con ID: " + str(idAppuntamento))

def f6(clienteRepo,appuntamentoRepo): # Cancella Appuntamento
    z=IO.idAppuntamento()
    appuntamento=appuntamentoRepo.get(z)
    appuntamentoRepo.delete(appuntamento.id)

def f7(clienteRepo,appuntamentoRepo): # Sposta Appuntamento
    z=IO.idAppuntamento()
    nuovoAppuntamento=IO.acqAppuntamento()
    idAppuntamento=appuntamentoRepo.add(nuovoAppuntamento)
    IO.visMsg("Appuntamento creato con ID: " + str(idAppuntamento))
    appuntamento=appuntamentoRepo.get(z)
    appuntamentoRepo.delete(appuntamento.id)

def f8(clienteRepo,appuntamentoRepo): # Visualizza Agenda
    date=IO.intervalloDate()
    listaAppuntamenti=appuntamentoRepo.getAppByDateRange(date[0],date[1])
    IO.visMsg("Gli appuntamenti nelle date selezionate sono: ")
    for app in listaAppuntamenti:
        var=clienteRepo.get(app.idCliente)
        IO.visMsg(app.info() + " " + var.info())
    
def main():

    clienteRepo=repository.ClienteRepo()
    appuntamentoRepo=repository.AppuntamentoRepo()

    dictionary={
        '1':['Nuovo Cliente',f1],
        '2':['Informazioni Cliente',f2],
        '3':['Modifica Cliente',f3],
        '4':['Elimina Cliente',f4],
        '5':['Prenota appuntamento',f5],
        '6':['Cancella appuntamento', f6],
        '7':['Sposta appuntamento', f7],
        '8':['Visualizza Agenda', f8],
        'U':['Uscita']
    }    

    menu = Menu(dictionary)
    menu.prospetta()
    scelta=menu.acqScelta()
    while not menu.uscita(scelta):
        dictionary[scelta][1](clienteRepo,appuntamentoRepo)
        menu.prospetta()
        scelta=menu.acqScelta()

main()
