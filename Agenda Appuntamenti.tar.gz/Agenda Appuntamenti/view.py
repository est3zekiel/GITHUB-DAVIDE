# View = IO
from cliente import Cliente
from appuntamento import Appuntamento
import datetime

class IO:
    
    def acqCliente():
        c=Cliente()
        c.nome=input("Nome -> ")
        c.cognome=input("Cognome -> ")
        c.telefono=input("Telefono -> ")
        return c
    
    def visCliente(cliente):
        print(cliente.info())

    def visMsg(k):
        print(k)

    def acqAppuntamento():
        app=Appuntamento()
        giorno=int(input("Giorno -> "))
        mese=int(input("Mese -> "))
        anno=int(input("Anno -> "))
        app.data=datetime.datetime(anno, mese, giorno)
        app.ora=int(input("Ora -> "))
        app.idCliente=int(input("ID Cliente -> "))
        return app
    
    def idAppuntamento():
        return int(input("ID Appuntamento -> "))

    def idCliente():
        return int(input("ID Cliente -> "))

    def intervalloDate():
        giorno_inizio=int(input("Giorno inizio -> "))
        mese_inizio=int(input("Mese inizio -> "))
        anno_inizio=int(input("Anno inizio -> "))
        giorno_fine=int(input("Giorno fine -> "))
        mese_fine=int(input("Mese fine -> "))
        anno_fine=int(input("Anno fine -> "))
        i=datetime.datetime(anno_inizio, mese_inizio, giorno_inizio)
        f=datetime.datetime(anno_fine, mese_fine, giorno_fine)
        return i, f

class Menu:
    def __init__(self, dictionary):
        self.dictionary = dictionary
        self.carUsc="u"
    def prospetta(self):
        for k in self.dictionary:
            print(k,self.dictionary[k][0])
    def acqScelta(self):
        return input("Scelta -> ")
    def uscita(self,scelta )->bool:
        return scelta.lower()==self.carUsc
    
