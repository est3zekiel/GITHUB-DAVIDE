x=3
x=(lambda x:x-1)

print(x)