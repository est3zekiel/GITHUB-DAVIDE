"""
import datetime as dt

giorno_corrente=dt.date.today()

print(giorno_corrente.strftime("%A / %d / %m / %Y"))
"""

def somma(a,b):
    c=a+b
    return c