 # Model = Repository

# il dizionario avrà chiave id(cliente) --> resto dei dati

class ClienteRepo:
    def __init__(self):
        self.diz=dict()
        self.progressivo=0
    def add(self, cliente):
        self.progressivo+=1
        cliente.id=self.progressivo
        self.diz[self.progressivo]=cliente
        return self.progressivo
    def get(self, id):
        return self.diz[id]
    def save(self, cliente):
        self.diz[cliente.id]=cliente
    def delete(self,id):
        self.diz.pop(id)

# il dizionario avrà chiave id --> appuntamento(id,data,idCliente)

class AppuntamentoRepo:
    def __init__(self):
        self.diz=dict()
        self.progressivo=0
    def add(self, appuntamento):
        self.progressivo+=1
        appuntamento.id=self.progressivo
        self.diz[self.progressivo]=appuntamento
        return self.progressivo
    def get(self, id):
        return self.diz[id]
    def save(self, appuntamento):
        self.diz[appuntamento.id]=appuntamento
    def delete(self,id):
        self.diz.pop(id)
    def getAppByCliente(self,cliente):
        res=list()
        for key in self.diz:
            app=self.diz[key]
            if int(app.idCliente)==int(cliente.id):
                res.append(app)
        return res
    def getAppByDateRange(self,dataInizio, dataFine):
        res=list()
        for app in self.diz.values():
            if app.data >= dataInizio and app.data <= dataFine:
                res.append(app)
        return res